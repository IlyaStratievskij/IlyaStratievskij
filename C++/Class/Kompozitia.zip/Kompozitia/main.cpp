#include <iostream>
#include <string>
#include "main.h"

using namespace std;

class Person {
    public:
        Person(string n, Birthday b)
        : name(n), bzd(b) {}
        void printInfo() {
            cout << name << " : ";
            bzd.printDate();
        }
    private:
        string name;
        Birthday bzd;
};

int main()
{
    Birthday b(27, 11, 2003);
    Person p("Ilya", b);
    p.printInfo();

    return 0;
}
