#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <iostream>
#include <cstdlib>

class Birthday {
    private:
        int day;
        int month;
        int year;

    public:
        Birthday(int di, int mi, int yi)
        : day(di), month(mi), year(yi)
        {}
        void printDate() {
            std::cout << day << '.' << month << '.' << year << std::endl;
        }



};

#endif // BD_H_INCLUDED
