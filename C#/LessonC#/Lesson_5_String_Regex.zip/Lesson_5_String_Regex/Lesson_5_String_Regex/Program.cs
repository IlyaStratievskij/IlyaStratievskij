﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace Lesson_5_String_Regex
{
    class Program
    {
        struct Info
        {
            public string name;
            public int count;
        }
        struct Element
        {
            public string FIO;
            public int N;
        }
        struct NewElement
        {
            public string tag;
            public string str;
            public NewElement(string tag, string newString)
            {
                this.tag = tag;
                str = newString;
            }
        }
        static void One()
        {
            Console.WriteLine("Введите строку: ");
            StringBuilder a = new StringBuilder(Console.ReadLine());
            Console.WriteLine("Исходная строка: " + a);
            for (int i = 0; i < a.Length;)
                if (char.IsPunctuation(a[i])) a.Remove(i, 1);
                else ++i;
            string str = a.ToString();
            string[] s = str.Split(' ');
            Console.WriteLine("Искомые слова: ");
            for (int i = 0; i < s.Length; ++i)
                if (s[i][0] == s[i][s[i].Length - 1]) Console.WriteLine(s[i]); 
        }

        static void Two()
        {
            int[] count = new int[26];

            int i = 0;
            char c;
            int Ca = (int)('a');
            Console.Write("Введите строку: ");
            string s = Console.ReadLine();
            s = s.ToLower();
            Console.WriteLine(s);
            s += '.';
            do
            {
                c = s[i];
                int k = (int)c;
                if (char.IsLower(c))
                    count[k-Ca]++;
                i++;
            } while (c != '.');

            for (i = 0; i < 26; i++)
                if (count[i] > 0)
                    // Если символ встретился хотя бы один раз
                    Console.WriteLine("{0}{1}", (char)(Ca + i), count[i]);
        }
        static void Four()
        {
            StreamReader sr = new StreamReader("data2.txt");
            int N = int.Parse(sr.ReadLine());
            Element[] a = new Element[N];
            for (int i = 0; i < N; i++)
            {
                string[] s = sr.ReadLine().Split(' ');
                a[i].FIO = s[0] + s[1];
                a[i].N = int.Parse(s[2]);
            }
            sr.Close();
            int[] massiv = new int[100];
            for (int i = 0; i < N; i++) massiv[a[i].N]++;
            int min = 100;
            for (int i = 0; i < 100; i++)
                if (massiv[i] != 0 && massiv[i] < min) min = massiv[i];

            for (int i = 0; i < 100; i++)
                if (massiv[i] == min) Console.WriteLine(i);

            //Console.ReadKey();
        }
        static void Three()
        {
            Info[] info = new Info[100];
            StreamReader sr = new StreamReader("data.txt");
            int N = int.Parse(sr.ReadLine());
            for (int i = 0; i < N; i++)
            {
                string s = sr.ReadLine();
                string[] ss = s.Split(' ');
                int c = 1;
                for (int j = 0; j < i; j++)
                    if (ss[0] == info[j].name) c++;
                info[i].name = ss[0];
                info[i].count = c;
            }
            sr.Close();
            for (int i = 0; i < N; i++)
            {
                Console.Write(info[i].name);
                if (info[i].count > 1) Console.Write(info[i].count);
                Console.WriteLine();
            }
        }
        static void Five()
        {
            string s = File.ReadAllText("shablon.txt");

            NewElement[] e = new NewElement[8]
            {
                new NewElement("name1","ООО 'Дружба'"),
                new NewElement("name2","Иванову И.И."),
                new NewElement("name3","менеджера по продажам"),
                new NewElement("name4","Сидорова А.А."),
                new NewElement("name5","Сидоров А.А."),
                new NewElement("data1","01.06.16"),
                new NewElement("data2","14.06.16"),
                new NewElement("data3","20.04.16"),
            };

            foreach(var el in e)
            {
                Regex r = new Regex("<" + el.tag + ">");
                s = r.Replace(s, el.str);
            }
            Console.WriteLine(s);
        }
        static void Main(string[] args)
        {
            string str1 = "Первая строка";
            string str2 = string.Copy(str1);
            string str3 = "Вторая строка";
            string str4 = "ВТОРАЯ строка";
            string strUp, strLow;
            int result, idx;
            Console.WriteLine("str1: " + str1);
            Console.WriteLine("Длина строки str1: " + str1.Length);
            // создаем прописную и строчную версии строки str1.
            strLow = str1.ToLower();
            strUp = str1.ToUpper();
            Console.WriteLine("Строчная версия строки str1: " + strLow);
            Console.WriteLine("Прописная версия строки str1: " + strUp);
            Console.WriteLine();
            // сравниваем строки
            result = str1.CompareTo(str3);
            if (result == 0) Console.WriteLine("str1 и str3 равны.");
            else if (result < 0) Console.WriteLine("str1 меньше, чем str3");
            else Console.WriteLine("str1 больше, чем str3");
            Console.WriteLine();

            // сравниваем строки без учета регистра
            result = String.Compare(str3, str4, true);
            if (result == 0) Console.WriteLine("str3 и str4 равны без учета регистра.");
            else Console.WriteLine("str3 и str4 не равны без учета регистра.");
            Console.WriteLine();
            // сравниваем части строк
            result = String.Compare(str1, 4, str2, 4, 2);
            if (result == 0) Console.WriteLine("часть str1 и str2 равны");
            else Console.WriteLine("часть str1 и str2 не равны");
            Console.WriteLine();

            // поиск строк
            idx = str2.IndexOf("строка");
            Console.WriteLine("Индекс первого вхождения подстроки сторка: " + idx);
            idx = str2.LastIndexOf("о");
            Console.WriteLine("Индекс последнего вхождения символа о: " + idx);
            // конкатенация
            string str = String.Concat(str1, str2, str3, str4);
            Console.WriteLine(str);
            // удаление подстроки
            str = str.Remove(0, str1.Length);
            Console.WriteLine(str);
            // замена подстроки "строка" на пустую подстроку
            str = str.Replace("строка", "");
            Console.WriteLine(str);


            string poems = "белеет парус одинокий в тумане моря голубом";
            char[] div = { ' ' }; // создаем массив разделителей
                                  // разбиваем строку на части,

            string[] parts = poems.Split(' ');
            Console.WriteLine("Результат разбиения строки на части: ");
            for (int i = 0; i < parts.Length; i++)
                Console.WriteLine(parts[i]);

            // собираем эти части в одну строку, в качестве разделителя используем символ |
            string strd = String.Join("|", parts);
            Console.WriteLine("Результат сборки: ");
            Console.WriteLine(strd);

            const int iIterations = 10000;

            DateTime dt = DateTime.Now;
            string strone = String.Empty;
            for (int i = 0; i < iIterations; i++)
                strone += "abcdefghijklmnopqrstuvwxyz\r\n";
            Console.WriteLine(DateTime.Now - dt);

            dt = DateTime.Now;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < iIterations; i++)
                sb.Append("abcdefghijklmnopqrstuvwxyz\r\n");
            string strtwo = sb.ToString();
            Console.WriteLine(DateTime.Now - dt);

            //One();
            //Two();
            Three();
            Four();
            Five();
        }
    }
}
