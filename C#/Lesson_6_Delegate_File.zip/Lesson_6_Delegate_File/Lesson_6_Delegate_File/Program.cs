﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

/*
namespace Lesson_6_File
{
    class Program
    {

        static void One()
        {
            StreamReader file = new StreamReader("mail.txt");
            string str = file.ReadToEnd();
            Regex r = new Regex(@"(\w+@[a-zA-z_]+?\.[a-zA-Z]{2,6})");
            Match integer = r.Match(str);
            while(integer.Success)
            {
                Console.WriteLine(integer);
                integer = integer.NextMatch();
            }
            file.Close();
        }
        static void Main()
        {
            FileStream fileIn = new FileStream("data.txt", FileMode.Open, FileAccess.Read);

            FileStream fileOut = new FileStream("newData.txt", FileMode.Create, FileAccess.Write);
            FileStream f2 = new FileStream("data.bin", FileMode.Create, FileAccess.Write);
            
            
            int i;
            while ((i = fileIn.ReadByte()) != -1)
            {
                // запись очередного байта в поток, связанный с файлом fileOut
                fileOut.WriteByte((byte)i);
                f2.WriteByte((byte)13);
            }
            fileIn.Close();
            fileOut.Close();
            f2.Close();

            StreamReader fileIn1 = new StreamReader("hobbit.txt");
            StreamWriter fileOut1 = new StreamWriter("numbers.txt", false);
            string text = fileIn1.ReadToEnd();
            Regex r = new Regex(@"[-+]?\d+");
            Match integer = r.Match(text);
            while (integer.Success)
            {
                Console.WriteLine(integer);
                fileOut1.WriteLine(integer);
                integer = integer.NextMatch();
            }
            fileIn1.Close();
            fileOut1.Close();
            
            FileStream f = new FileStream("data.bin", FileMode.Open);
            BinaryReader fIn = new BinaryReader(f);
            long n = f.Length / 4; // определяем количество чисел в двоичном потоке
            int a;
            for (i = 0; i < n; i++)
            {
                a = fIn.ReadInt32();
                Console.Write(a + " ");
            }
            fIn.Close();
            f.Close();
            Console.WriteLine();
            One();
        }
        
    }
}
*/
/*
namespace Lesson_6_Delegate
{
    public delegate double Fun(double x, double y);
    public delegate double Fin(double x);
    class Program
    {
        // Создаем метод, который принимает делегат
        // На практике этот метод сможет принимать любой метод
        // с такой же сигнатурой, как у делегата
        public static void Table(Fun F, double x, double b)
        {
            Console.WriteLine("----- X ----- Y -----");
            while (x <= b)
            {
                Console.WriteLine("| {0,8:0.000} | {1,8:0.000} |", x, F(x, b));
                x += 1;
            }
            Console.WriteLine("---------------------");
        }
        public static void Table(Fin F, double x, double b)
        {
            Console.WriteLine("----- X ----- Y -----");
            while (x <= b)
            {
                Console.WriteLine("| {0,8:0.000} | {1,8:0.000} |", x, F(x));
                x += 1;
            }
            Console.WriteLine("---------------------");
        }
        // Создаем метод для передачи его в качестве параметра в Table
        public static double MyFunc(double x, double a)
        {
            return a * x * x ;
        }
        public static double MyFunc(double x)
        {
            return x * x;
        }
        static void Main()
        {
            // Создаем новый делегат и передаем ссылку на него в метод Table
            Console.WriteLine("Таблица функции MyFunc:");

            // Параметры метода и тип возвращаемого значения, должны совпадать с делегатом

            Table(new Fun(MyFunc), -2, 2);
            Console.WriteLine("Еще раз та же таблица, но вызов организован по новому");

            // Упрощение(c C# 2.0).Делегат создается автоматически.

            //Table(MyFunc, -2, 2);
            Console.WriteLine("Таблица функции Sin:");
            Table(Math.Sin, -2, 2); // Можно передавать уже созданные методы

            Console.WriteLine("Таблица функции x^2:");
            // Упрощение(с C# 2.0). Использование анонимного метода
            Table(delegate (double x, double y) { return y * x * x; }, 0, 3);
        }
    }
}
*/
namespace Lesson_6_Delegate
{
    class Student
    {
        public string lastName;
        public string firstName;
        public string university;
        public string faculty;
        public int course;
        public string department;
        public int group;
        public string city;
        int age;
        // Создаем конструктор
        public Student(string firstName, string lastName, string university,
        string faculty, string department, int course, int age, int group, string city)
        {
            this.lastName = lastName;
            this.firstName = firstName;
            this.university = university;
            this.faculty = faculty;
            this.department = department;
            this.course = course;
            this.age = age;
            this.group = group;
            this.city = city;
        }
    }
    class Program
    {
        static int MyDelegat(Student st1, Student st2)
        {
            //return String.Compare(st1.firstName, st2.firstName);
            //return st1.age < st2.age;  // нет доступа изз ауровня защиты
            if (st1.course > st2.course) return 1;
            else if (st1.course < st2.course) return -1;
            else return 0;
        }
        static void Main()
        {
            int bakalavr = 0;
            int magistr = 0;
            List<Student> list = new List<Student>();
            DateTime dt = DateTime.Now;
            StreamReader sr = new StreamReader("student.txt");
            while (!sr.EndOfStream)
            {
                try
                {
                    string[] s = sr.ReadLine().Split(' ');
                    list.Add(new Student(s[0], s[1], s[2], s[3], s[4], int.Parse(s[5]), int.Parse(s[6]), int.Parse(s[7]), s[8]));

                    if (int.Parse(s[5]) < 5) bakalavr++; else magistr++;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            sr.Close();
            list.Sort(new Comparison<Student>(MyDelegat));
            Console.WriteLine("All student = " + list.Count);
            Console.WriteLine("Магистров:{0}", magistr);
            Console.WriteLine("Бакалавров:{0}", bakalavr);
            foreach (var v in list) Console.WriteLine(v.firstName);
            Console.WriteLine(DateTime.Now - dt);
        }
    }
}
