﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Globalization;

/*
namespace Lesson_27_32
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Random rand = new Random();

            int[,] arr2 = new int[5, 7];

            for (int i = 0; i < arr2.GetLength(0); i++)
            {
                for (int j = 0; j < arr2.GetLength(1); j++)
                {
                    arr2[i, j] = rand.Next(100);
                    Console.Write($"{arr2[i, j]}\t");
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            int[] myArray = { 0, 23, 3, 2, 6, 57, 34, 23, 3, 2, 0, 111 };
            int[] res = myArray.Distinct().ToArray();
            for (int i = 0; i < res.Length; i++) Console.Write($"{res[i]}\t");
            Console.WriteLine();

            res = res.OrderByDescending(i => i).ToArray();
            for (int i = 0; i < res.Length; i++) Console.Write($"{res[i]}\t");
            Console.WriteLine();

            res = res.Where(i => i % 2 != 0).ToArray();
            for (int i = 0; i < res.Length; i++) Console.Write($"{res[i]}\t");
            Console.WriteLine();

            int[] myArray2 = myArray[^4..^1];
            for (int i = 0; i < myArray2.Length; i++) Console.Write($"{myArray2[i]}\t");
            Console.WriteLine();
            Console.WriteLine(myArray2[^1]);

            foreach (var item in myArray[1..6])
                Console.Write($"{item}\t");

            Console.ReadKey();
        }
    }
}
*/
/*
namespace Lesson_33
{
    class Hello_world
    {
        static void Main()
        {
            Random rand = new Random();

            int[][] myArr = new int[4][];
            myArr[0] = new int[5];
            myArr[1] = new int[3];
            myArr[2] = new int[10];
            myArr[3] = new int[6];

            for (int i = 0; i < myArr.Length; i++)
            {
                for (int j = 0; j < myArr[i].Length; j++)
                {
                    myArr[i][j] = rand.Next(50);
                    Console.Write($"{myArr[i][j]}\t");
                }
                Console.WriteLine();
            }

            Console.WriteLine();
            int[,,] arr3 = new int[3, 4, 5];

            for (int i = 0; i < arr3.GetLength(0); i++)
            {
                Console.WriteLine("Page № " + (i + 1));
                for (int j = 0; j < arr3.GetLength(1); j++)
                {
                    for (int k = 0; k < arr3.GetLength(2); k++)
                    {
                        arr3[i, j, k] = rand.Next(20);
                        Console.Write($"{arr3[i, j, k]}\t");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("----------------------------------");
            }

            Console.WriteLine();
            int[][][] myArr3 = new int[rand.Next(3, 7)][][];

            for (int i = 0; i < myArr3.Length; i++)
            {
                Console.WriteLine("Page № " + (i + 1));
                myArr3[i] = new int[rand.Next(2, 6)][];
                for (int j = 0; j < myArr3[i].Length; j++)
                {
                    myArr3[i][j] = new int[rand.Next(3, 9)];
                    for (int k = 0; k < myArr3[i][j].Length; k++)
                    {
                        myArr3[i][j][k] = rand.Next(50);
                        Console.Write($"{myArr3[i][j][k]}\t");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("----------------------------------");
            }


            Console.ReadKey();
        }
    }
}
*/
/*
namespace Lesson_35_37
{
    class Hello_World 
    {
        static int Sum(int a, int b, int c)
        {
            return a + b + c;
        }
        static int Sum(int a, int b)
        {
            return a + b;
        }
        static void Main()
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine(Sum(a, b));
            Console.WriteLine(Sum(a, b, a+b));
        }
    }
}
*/
/*
namespace Lesson_40_43
{

    struct MyStruct
    {
        public int a;
        public double b;
        public float c;
    }
    class MyClass 
    {
        public int a;
        public double b;
        public float c;
    }

    class Hello_World
    {
        static void Foo(MyClass mystruct)
        {
            mystruct.a = -5;
        }
        static void Foo(ref MyStruct mystruct)
        {
            mystruct.a = -5;
        }
        static void Foo(ref int a)
        {
            a = -5;
        }
        static void Main()
        {
            string str = null;
            string res = str ??= "not stated";

            Console.WriteLine(str);

            int[] myArr = null;
            myArr ??= new int[0];
            Console.WriteLine(myArr.Length);

            int[] arr = null;
            Console.WriteLine(arr?.Sum() ?? 0);

            int a = 9;
            Foo(ref a);
            Console.WriteLine(a);

            MyStruct mystruct = new MyStruct();

            Foo(ref mystruct);
            Console.WriteLine(mystruct.a);

            MyClass myclass = new MyClass();

            Foo(myclass);
            Console.WriteLine(myclass.a);

            ref int b = ref a;

            b = 3;
            Console.WriteLine(a);
        }
    }
}*/
/*
namespace Lesson_HomeWork_12_14
{
    class Hello_World
    {
        static void Resize<T>(ref T[] arr, int n)
        {
            T[] new_arr = new T[n];
            for (int i = 0; i < arr.Length && i < new_arr.Length; i++)
            {
                new_arr[i] = arr[i];
            }
            arr = new_arr;
        }

        static void AddElemIndex(ref int[] arr, int n, int id)
        {
            int[] new_arr = new int[arr.Length + 1];
            for (int i = 0, j = 0; i < arr.Length; i++, j++)
            {
                if (j == id)
                {
                    new_arr[j] = n;
                    i--;
                }
                else new_arr[j] = arr[i];
            }
            arr = new_arr;
        }

        static void DeleteElemIndex(ref int[] arr, int id)
        {
            int[] new_arr = new int[arr.Length - 1];
            for (int i = 0, j = 0; i < arr.Length; i++, j++)
            {
                if (i == id) { j--; }

                else new_arr[j] = arr[i];
            }
            arr = new_arr;
        }
        static void Main()
        {
            Random rand = new Random();

            int[] arr = new int[rand.Next(5, 15)];
            for (int i = 0;i < arr.Length; i++)
            {
                arr[i] = rand.Next(50);
                Console.Write($"{arr[i]}\t");
            }
            Console.WriteLine();

            Resize(ref arr, rand.Next(5, 15));
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{arr[i]}\t");
            }
            Console.WriteLine();
            AddElemIndex(ref arr, rand.Next(5, 15), rand.Next(arr.Length));
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{arr[i]}\t");
            }
            Console.WriteLine();
            DeleteElemIndex(ref arr, rand.Next(arr.Length));
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{arr[i]}\t");
            }
        }
    }
}
*/
/*
namespace Lesson_HomeWork_16_17
{
    class Hello_World
    {
        static int Numb(int arr, int sum = 0)
        {
            if (arr == 0) return sum;
            else return sum += Numb(arr / 10,  arr % 10);
        }
        static int Sum(int[] arr, int i = 0, int sum = 0)
        {
            if (i == arr.Length) return sum;
            else return sum += Sum(arr, i + 1, arr[i]);
        }
        static void Main()
        {
            Random rand = new Random();

            int[] arr = new int[5];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.Next(35);
                Console.Write($"{arr[i]}\t");
            }
            Console.WriteLine();
            Console.WriteLine($"{Sum(arr)}");

            Console.WriteLine($"{Numb(Sum(arr))}");

            Console.ReadKey();
        }
    }
}
*/
/*
namespace Lesson_50_53
{
    class Hello_World
    {
        static void Foo(byte a)
        {
            Console.WriteLine(a);
        }
        static void Main()
        {

            byte a = 1;
            byte b = 1;
            a = checked((byte)(a - b));

            Foo(a);

            int c = int.MaxValue;
            c++;
            Console.WriteLine(c);

            string str = null;

            int cba = 2;
            int? abc = null;
            int? res = cba + abc;

            Console.WriteLine(res);

            var t = "string";
            Console.WriteLine(t.GetType());

            var d = new Dictionary<int, string>();
            Console.WriteLine(d.GetType());

            var v = new { Name = "Ilya", Age = 25 };
            Console.WriteLine(v.GetType());

            int[] numb = { 1, 34, 342, 4, 2, 56, 6, 4, 3, 55 };
            var r = from i in numb where i % 2 == 0 && i > 15 orderby i select i;

            foreach (var j in r)
                Console.Write($"{j}\t");

            Console.ReadKey();
        }
    }
}
*/
/*
namespace Lesson_54
{
    class Hello_World
    {
        enum DayWeek : byte
        {
            Monday = 1,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday
        }
        static void Main()
        {

            //while (true)
            // {
            //ConsoleKey key = Console.ReadKey().Key;
            //int keyCode = (int)key;
            //Console.WriteLine($"\nEnum: {key}, Code: {keyCode}");
            //}

            DayWeek dayofweek = DayWeek.Monday;

            Console.WriteLine(Enum.GetUnderlyingType(typeof(DayWeek)));

            Console.WriteLine(dayofweek);

            Console.WriteLine((int)dayofweek);

            Console.WriteLine((DayWeek)3);

        }
    }
}
*/
namespace Lesson_55
{
    class Student
    {
        public Guid id;
        public string firstName;
        public string secondName;
        public int age;
        public string groop;
    }
    class Program
    { 
        static Student GetStudent()
        {
            Student student = new Student();

            student.firstName = "Ilya";
            student.secondName = "Bombila";
            student.id = Guid.NewGuid();
            student.age = 19;
            student.groop = "P1-19";

            return student;
        }

        static void Print(Student student)
        {
            Console.WriteLine("Information about student:");
            Console.WriteLine($"Id: {student.id}");
            Console.WriteLine($"Age: {student.age}");
            Console.WriteLine($"Name: {student.firstName}");
            Console.WriteLine($"Surname: {student.secondName}");
            Console.WriteLine($"Group: {student.groop}");
        }
        static void Main()
        {
            var firstStudent = GetStudent();

            Print(firstStudent);
        }
    }
}